import elagazas
import sorozat
import greenaway_m

elagazas.hossz()
sorozat.legkisebb(sorozat.letrehoz(100,200))
adatok = greenaway_m.beolvas()
# greenaway_m.kiir(adatok)
greenaway_m.filmekszama(adatok)
greenaway_m.d(adatok)
